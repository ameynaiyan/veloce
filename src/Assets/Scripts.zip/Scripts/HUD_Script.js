var speedskin : GUISkin;
var def : GUISkin;
var postex : Texture;
function OnGUI () {
    GUI.skin=speedskin;
}