var pastTime :float;
var guiTime :GUIText;

function Update()
{
	pastTime+=Time.deltaTime;
	guiTime.text=pastTime.ToString();
}