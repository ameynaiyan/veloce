var m : Material;
var color : Color;
function Update () {
renderer.material.SetColor("_TintColor",color);
}