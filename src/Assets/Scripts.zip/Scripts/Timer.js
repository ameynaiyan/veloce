var StartTime :float;
var guiTime :GUIText;
var timeremaining: float;
var guiTimeUp: GUIText;
var timeskin:GUISkin;
var timestring:String;
function Start()
{

guiTimeUp.enabled=false;
}

function Update()
{
	if(PlayerPrefs.GetInt("gameMode")==2){
	var start=PlayerPrefs.GetInt("gameactive");
/*	pastTime+=Time.deltaTime;
	guiTime.text=pastTime.ToString("0.00");*/
	if(start==1)
		CountD();
	}
}

function CountD()
{
timeremaining =StartTime-Time.time;
ShowTime();

if(timeremaining<0)
{
guiTimeUp.enabled=true;
guiTimeUp.text="TIME IS UP!!"; 
guiTime.text="0";
timeIsUp();
}

}

function ShowTime()
{
var min:int;
var sec:int;
min=timeremaining/60;
sec=timeremaining%60;
timestring=min.ToString()+":"+sec.ToString("00");
}

function timeIsUp()
{
 PlayerPrefs.SetInt("gameactive",0);
	yield WaitForSeconds(1);
	Application.LoadLevel("m3");
}

function OnGUI()
{
	if(PlayerPrefs.GetInt("gameMode")==2&&PlayerPrefs.GetInt("gameactive")==1){
	GUI.skin=timeskin;
	GUI.Label (Rect (45,64,200,150), timestring);
	if(timeremaining<0)
		GUI.Label (Rect (Screen.width/2-100,24,200,150), timestring);
	}
}
		