var newSkin : GUISkin;
var circuit1: int=0;
var ckt:int=0;
var mode:int;


function Start(){
ckt=PlayerPrefs.GetInt("ckt_select");
circuit1=PlayerPrefs.GetInt("SavedLevel1");
mode=PlayerPrefs.GetInt("gameMode");
}
function theCarMenu() {
    GUI.BeginGroup(Rect(0, 0, Screen.width, Screen.width));
    var i:int;
    var script3 = GetComponent("CarSelectScript"); 
    script3.enabled = true;
    var script5 = GetComponent("FadeInOut");
    
    //buttons
    if(mode!=3)
    {
    if(GUI.Button(Rect(Screen.width-340, Screen.height-70, 400, 70), "RACE")) {
    script5.fadeOut();
    if(ckt==0)
    	PlayerPrefs.SetInt("gameState",10);
    else if(ckt==1)
    	PlayerPrefs.SetInt("gameState",11);
    else if(ckt==2)
    	PlayerPrefs.SetInt("gameState",12);
    else if(ckt==3)
    	PlayerPrefs.SetInt("gameState",13);
    Application.LoadLevel("loading2");
    }
    if(GUI.Button(Rect(-60,Screen.height-70, 400, 70), "SELECT CIRCUIT")) {
    script5.fadeOut();
    Application.LoadLevel("m3");
    }
    }
    else
    {
    if(GUI.Button(Rect(Screen.width-340, Screen.height/2-35, 400, 70), "RACE")) {
    script5.fadeOut();
    if(ckt==0)
    	PlayerPrefs.SetInt("gameState",10);
    else if(ckt==1)
    	PlayerPrefs.SetInt("gameState",11);
    else if(ckt==2)
    	PlayerPrefs.SetInt("gameState",12);
    else if(ckt==3)
    	PlayerPrefs.SetInt("gameState",13);
    Application.LoadLevel("loading2");
    }
    if(GUI.Button(Rect(-60,Screen.height/2-35, 400, 70), "SELECT CIRCUIT")) {
    script5.fadeOut();
    Application.LoadLevel("m3");
    }
    }
    //layout end
    GUI.EndGroup(); 
}

function OnGUI () {
    //load GUI skin 
    GUI.skin = newSkin;
    
    //execute theMapMenu function
    theCarMenu();
}