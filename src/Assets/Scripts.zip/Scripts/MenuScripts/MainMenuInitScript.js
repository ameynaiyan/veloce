var soundName : AudioClip;
function Start(){
	yield WaitForSeconds(0.3);
	audio.Play();
}