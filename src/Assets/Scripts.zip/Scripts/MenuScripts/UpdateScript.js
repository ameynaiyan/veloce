function Update () {

if(Input.GetKey("escape")) {
    //pause the game
    Time.timeScale = 0;
    camera.GetComponent(BlurEffect).enabled = true;
    AudioListener.pause=true;
   	
   	//show the pause menu
    var script3 = GetComponent("PauseMenuScript"); 
    script3.enabled = true;
    //disable the cursor hiding script
    var script4 = GetComponent("HideCursorScript"); 
    script4.enabled = false; 
    }
}