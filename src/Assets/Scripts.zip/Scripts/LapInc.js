var lap :int;
var cpt :int;
var lapback :Texture;
var speedskin : GUISkin;
var nol : int;
var value:int;
var pid:int;
var isai:boolean;
function Start()
{
	lap=0;
	cpt=2;
	if(isai==false)
		pid = GetComponent("PlayerCar_Script").id;
}
function OnTriggerEnter(col:Collider)
{
	if((col.gameObject.name == "SF")&&(cpt==2))
	{
		lap++;
		cpt=0;
	}
	if(col.gameObject.name == "CPT1"&&cpt==0)
	{
		cpt=1;
	}
	if(col.gameObject.name == "CPT2"&&cpt==1)
	{
		cpt=2;
	}
	if(PlayerPrefs.GetInt("gameMode")!=2&&PlayerPrefs.GetInt("gameactive")==1){
	if(lap==nol+1)
	{
			PlayerPrefs.GetInt("gameactive",0);
			PlayerPrefs.SetInt("SavedLevel1", value);
            Debug.Log("SavedLevel = value");
			yield WaitForSeconds(2.0);
            Application.LoadLevel("m3");
	}
	}
}

function OnGUI()
{
	if(isai==false){
	GUI.skin=speedskin;
	if(PlayerPrefs.GetInt("gameactive")==1){
		if(PlayerPrefs.GetInt("gameMode")==3){
			if(pid==2){
				GUI.Label (Rect (0,Screen.height/2,160,160), lapback);
				GUI.Label (Rect (50,Screen.height/2+36,200,150), "Lap");
				GUI.Label (Rect (45,Screen.height/2+72,200,150), (lap.ToString()+"/"+nol));
			}
			else if(pid==1)
			{
				GUI.Label (Rect (0,0,160,160), lapback);
				GUI.Label (Rect (50,36,200,150), "Lap");
				GUI.Label (Rect (45,72,200,150), (lap.ToString()+"/"+nol));
			}
		}
		else if(PlayerPrefs.GetInt("gameMode")!=2){
			GUI.Label (Rect (0,0,160,160), lapback);
			GUI.Label (Rect (50,36,200,150), "Lap");
			GUI.Label (Rect (45,72,200,150), (lap.ToString()+"/"+nol));
		}
	}
	}
}